<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <a href="index.php"><h1>ГЛАВНАЯ</h1></a>
    <ul>
        <li><a href="poisk.php">Поиск</a></li>
        <li><a href="voiti.php">Войти</a></li>
        <li><a href="registr.php">Зарегистрироваться</a></li>
    </ul>
</body>
</html>