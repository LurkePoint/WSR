<?php
$connection = mysqli_connect( 'localhost', 'root', '');
$celect_db = mysqli_select_db( $connection, 'SiteUzen');
?>